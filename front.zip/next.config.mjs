/** @type {import('next').NextConfig} */
const nextConfig = {
    env: {
      NEXT_PUBLIC_SITE_URL: 'http://kuk.solution:3000'
    }
  };
  
  export default nextConfig;
  