export interface User {
  name?: string;
  avatar?: string;
  role?: string;
  [key: string]: unknown;
}
