import { useEffect, useState } from 'react';
import axios from 'axios';

export function useUserType(): { userType: 'PERSONAL' | 'ENTERPRISE' | null, isLoading: boolean, error: string | null } {
  const [userType, setUserType] = useState<'PERSONAL' | 'ENTERPRISE' | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchUserType() {
      try {
        const response = await axios.get('/auth/user');
        setUserType(response.data.role);
      } catch (err) {
        setError('Failed to fetch user type');
      } finally {
        setIsLoading(false);
      }
    }

    fetchUserType();
  }, []);

  return { userType, isLoading, error };
}
